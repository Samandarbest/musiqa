plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="uz.musiqa.app";compileSdk=34
defaultConfig{applicationId="uz.musiqa.app";minSdk=24;targetSdk=34;versionCode=1;versionName="1.0"}
buildTypes{release{isMinifyEnabled=false}}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}}
