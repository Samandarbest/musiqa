plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="uz.musiqa.app";compileSdk=34
defaultConfig{applicationId="uz.musiqa.app";minSdk=24;targetSdk=34
versionCode=(project.findProperty("vCode") as String?)?.toIntOrNull()?:1;versionName="1.0"}
// Doimiy imzo: yangilanishlar eski ilova ustiga o'rnatilishi uchun shart
signingConfigs{create("fixed"){storeFile=file("musiqa.keystore");storePassword="musiqa123";keyAlias="musiqa";keyPassword="musiqa123";storeType="pkcs12"}}
buildTypes{getByName("debug"){signingConfig=signingConfigs.getByName("fixed")};release{isMinifyEnabled=false;signingConfig=signingConfigs.getByName("fixed")}}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}}
dependencies{implementation("androidx.core:core:1.13.1")}
