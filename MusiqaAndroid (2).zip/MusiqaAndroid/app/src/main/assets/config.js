window.SERVER="";
