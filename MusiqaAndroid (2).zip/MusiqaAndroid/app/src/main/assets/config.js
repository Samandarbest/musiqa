window.SERVER="https://6a60ca824cbca.myxvest1.ru/musicbot";
