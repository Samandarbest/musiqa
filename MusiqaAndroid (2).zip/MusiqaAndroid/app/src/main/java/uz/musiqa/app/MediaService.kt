package uz.musiqa.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.view.KeyEvent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.net.URL
import kotlin.concurrent.thread

// Telefonning yuqoridan tushadigan paneli va qulf ekranida pleyer ko'rsatadi
@Suppress("DEPRECATION")
class MediaService : Service() {
    companion object {
        @Volatile var cb: ((String) -> Unit)? = null
        const val CH = "musiqa_media"
        const val ACT = "uz.musiqa.CMD"
    }
    private lateinit var session: MediaSession
    private val ui = Handler(Looper.getMainLooper())
    private var title = ""; private var artist = ""; private var cover = ""
    private var playing = false; private var dur = 0L
    private var bmp: Bitmap? = null
    private var wl: PowerManager.WakeLock? = null
    private val noisy = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { cb?.invoke("pause") } }
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { cb?.invoke(i?.getStringExtra("c") ?: "") }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(CH, "Musiqa", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "musiqa")
        @Suppress("DEPRECATION") session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        session.setCallback(object : MediaSession.Callback() {
            // Bluetooth quloqchin va mashina tugmalari
            override fun onMediaButtonEvent(i: Intent): Boolean {
                @Suppress("DEPRECATION") val k = i.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return false
                if (k.action != KeyEvent.ACTION_DOWN) return true
                when (k.keyCode) {
                    KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> cb?.invoke("toggle")
                    KeyEvent.KEYCODE_MEDIA_PLAY -> cb?.invoke("play")
                    KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_MEDIA_STOP -> cb?.invoke("pause")
                    KeyEvent.KEYCODE_MEDIA_NEXT -> cb?.invoke("next")
                    KeyEvent.KEYCODE_MEDIA_PREVIOUS -> cb?.invoke("prev")
                    else -> return false
                }
                return true
            }
            override fun onPlay() { cb?.invoke("play") }
            override fun onPause() { cb?.invoke("pause") }
            override fun onSkipToNext() { cb?.invoke("next") }
            override fun onSkipToPrevious() { cb?.invoke("prev") }
            override fun onSeekTo(pos: Long) { cb?.invoke("seek:$pos") }
        })
        session.isActive = true
        registerReceiver(noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        val f = IntentFilter(ACT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rcv, f)
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i == null) return START_NOT_STICKY
        title = i.getStringExtra("t") ?: ""; artist = i.getStringExtra("a") ?: ""
        playing = i.getBooleanExtra("p", false); dur = i.getLongExtra("dur", 0)
        val pos = i.getLongExtra("pos", 0); val c = i.getStringExtra("c") ?: ""
        if (c != cover) { cover = c; bmp = null }
        session.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, pos, if (playing) 1f else 0f).build())
        post()
        if (cover.isNotEmpty() && bmp == null) {
            val u = cover
            thread {
                try {
                    val b = if (u.startsWith("file:")) BitmapFactory.decodeFile(Uri.parse(u).path)
                            else URL(u).openStream().use { BitmapFactory.decodeStream(it) }
                    ui.post { if (u == cover && b != null) { bmp = b; post() } }
                } catch (e: Exception) {}
            }
        }
        return START_NOT_STICKY
    }

    private fun act(c: String) = PendingIntent.getBroadcast(this, c.hashCode(),
        Intent(ACT).setPackage(packageName).putExtra("c", c), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun post() {
        val md = MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, artist).putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
        bmp?.let { md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) }
        session.setMetadata(md.build())
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(artist)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(playing).setShowWhen(false)
            .setContentIntent(PendingIntent.getActivity(this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE))
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Oldingi", act("prev")).build())
            .addAction(Notification.Action.Builder(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                "Ijro", act(if (playing) "pause" else "play")).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Keyingi", act("next")).build())
        bmp?.let { b.setLargeIcon(it) }
        b.setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
        startForeground(1, b.build())
        if (!playing) stopForeground(false)
        if (playing) { if (wl == null) wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "musiqa:play"); if (wl?.isHeld == false) wl?.acquire(6 * 3600 * 1000L) }
        else if (wl?.isHeld == true) wl?.release()
    }

    // Ilova so'nggi ilovalardan o'chirilganda: musiqa va bildirishnoma ham butunlay o'chadi
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopForeground(true)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
        stopSelf()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    override fun onDestroy() {
        try { unregisterReceiver(noisy) } catch (e: Exception) {}
        if (wl?.isHeld == true) wl?.release()
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        session.release()
        super.onDestroy()
    }
}
