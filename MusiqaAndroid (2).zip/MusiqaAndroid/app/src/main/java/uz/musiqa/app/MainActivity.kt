package uz.musiqa.app
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private val dir by lazy { File(filesDir, "music").also { it.mkdirs() } }

    @Suppress("DEPRECATION", "SetJavaScriptEnabled")
    private fun cfg() {
        val s = wv.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true; s.allowFileAccess = true
        s.allowFileAccessFromFileURLs = true; s.allowUniversalAccessFromFileURLs = true
        s.mediaPlaybackRequiresUserGesture = false
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#14101D"); window.navigationBarColor = Color.parseColor("#1E1830")
        wv = WebView(this); wv.setBackgroundColor(Color.parseColor("#14101D")); setContentView(wv)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cfg(); wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/app.html")
    }

    @Suppress("DEPRECATION")
    private fun imm(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else 0
    }

    private fun js(s: String) = runOnUiThread { wv.evaluateJavascript(s, null) }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { wv.evaluateJavascript("appBack()") { if (it != "true") finish() } }

    inner class Bridge {
        @JavascriptInterface fun saved(): String {
            val a = JSONArray()
            dir.listFiles { f -> f.extension == "json" }?.sortedByDescending { it.lastModified() }?.forEach { f ->
                try {
                    val o = JSONObject(f.readText()); val id = o.getInt("id"); val m = File(dir, "$id.mp3")
                    if (m.exists()) {
                        o.put("file", m.toURI().toString()); val c = File(dir, "$id.jpg")
                        o.put("cover", if (c.exists()) c.toURI().toString() else ""); a.put(o)
                    }
                } catch (e: Exception) {}
            }
            return a.toString()
        }
        @JavascriptInterface fun save(id: Int, audio: String, cover: String, meta: String) {
            thread {
                try {
                    val tmp = File(dir, "$id.part"); val c = URL(audio).openConnection(); c.connectTimeout = 15000
                    val len = c.contentLength.toLong(); var done = 0L; var last = -1
                    c.getInputStream().use { i -> tmp.outputStream().use { o ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (len > 0) { val p = (done * 100 / len).toInt(); if (p != last) { last = p; js("onProg($id,$p)") } }
                        } } }
                    tmp.renameTo(File(dir, "$id.mp3"))
                    if (cover.isNotEmpty()) try { URL(cover).openStream().use { i -> File(dir, "$id.jpg").outputStream().use { o -> i.copyTo(o) } } } catch (e: Exception) {}
                    File(dir, "$id.json").writeText(meta); js("onSaved($id,true)")
                } catch (e: Exception) { File(dir, "$id.part").delete(); js("onSaved($id,false)") }
            }
        }
        @JavascriptInterface fun immersive(on: Boolean) { runOnUiThread { imm(on) } }
        @JavascriptInterface fun remove(id: Int) { listOf("mp3", "jpg", "json").forEach { File(dir, "$id.$it").delete() } }
    }
}
