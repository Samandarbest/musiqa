package uz.musiqa.app
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var wv: WebView
    private val dir by lazy { File(filesDir, "music").also { it.mkdirs() } }

    @Suppress("DEPRECATION", "SetJavaScriptEnabled")
    private fun cfg() {
        val s = wv.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true; s.allowFileAccess = true
        s.allowFileAccessFromFileURLs = true; s.allowUniversalAccessFromFileURLs = true
        s.mediaPlaybackRequiresUserGesture = false
    }

    @Suppress("DEPRECATION")
    private fun imm(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else 0
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#14101D"); window.navigationBarColor = Color.parseColor("#1E1830")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        wv = WebView(this); wv.setBackgroundColor(Color.parseColor("#14101D")); setContentView(wv)
        cfg(); wv.addJavascriptInterface(Bridge(), "Android")
        MediaService.cb = { c -> js("mediaCmd('$c')") }
        wv.loadUrl("file:///android_asset/app.html")
    }

    private fun js(s: String) = runOnUiThread { wv.evaluateJavascript(s, null) }

    // Orqaga bosilganda ilova yopilmaydi, musiqa fonda davom etadi
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { wv.evaluateJavascript("appBack()") { if (it != "true") moveTaskToBack(true) } }

    override fun onDestroy() {
        MediaService.cb = null
        stopService(Intent(this, MediaService::class.java))
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface fun saved(): String {
            val a = JSONArray()
            dir.listFiles { f -> f.extension == "json" }?.sortedByDescending { it.lastModified() }?.forEach { f ->
                try {
                    val o = JSONObject(f.readText()); val id = o.getInt("id"); val m = File(dir, "$id.mp3")
                    if (m.exists()) {
                        o.put("file", m.toURI().toString()); val c = File(dir, "$id.jpg")
                        o.put("cover", if (c.exists()) c.toURI().toString() else ""); a.put(o)
                    }
                } catch (e: Exception) {}
            }
            return a.toString()
        }
        @JavascriptInterface fun save(id: Int, audio: String, cover: String, meta: String) {
            thread {
                try {
                    val tmp = File(dir, "$id.part"); val c = URL(audio).openConnection(); c.connectTimeout = 15000
                    val len = c.contentLength.toLong(); var done = 0L; var last = -1
                    c.getInputStream().use { i -> tmp.outputStream().use { o ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (len > 0) { val p = (done * 100 / len).toInt(); if (p != last) { last = p; js("onProg($id,$p)") } }
                        } } }
                    tmp.renameTo(File(dir, "$id.mp3"))
                    if (cover.isNotEmpty()) try { URL(cover).openStream().use { i -> File(dir, "$id.jpg").outputStream().use { o -> i.copyTo(o) } } } catch (e: Exception) {}
                    File(dir, "$id.json").writeText(meta); js("onSaved($id,true)")
                } catch (e: Exception) { File(dir, "$id.part").delete(); js("onSaved($id,false)") }
            }
        }
        @JavascriptInterface fun immersive(on: Boolean) { runOnUiThread { imm(on) } }
        // Bildirishnoma panelidagi pleyerni yangilash
        @JavascriptInterface fun media(t: String, a: String, c: String, p: Boolean, pos: Int, dur: Int) {
            val i = Intent(this@MainActivity, MediaService::class.java).putExtra("t", t).putExtra("a", a).putExtra("c", c)
                .putExtra("p", p).putExtra("pos", pos.toLong()).putExtra("dur", dur.toLong())
            try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) } catch (e: Exception) {}
        }
        @JavascriptInterface fun remove(id: Int) { listOf("mp3", "jpg", "json").forEach { File(dir, "$id.$it").delete() } }
    }
}
